This is the source code to the DMD compiler
for the D Programming Language defined in the documents at
http://dlang.org/

These sources are free, they are redistributable and modifiable
under the terms of the Boost Software License, Version 1.0.
The terms of this license are in the file boostlicense.txt,
or see http://www.boost.org/LICENSE_1_0.txt.

If a particular file has a different license in it, that overrides
this license for that file.

-Walter Bright
